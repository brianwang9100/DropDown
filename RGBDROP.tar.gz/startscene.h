#ifndef STARTSCENE_BITMAP_H
#define STARTSCENE_BITMAP_H
extern const unsigned short startscene[38400];
#define STARTSCENE_WIDTH 240
#define STARTSCENE_HEIGHT 160
#endif