#ifndef GROUND_BITMAP_H
#define GROUND_BITMAP_H
extern const unsigned short ground[2640];
#define GROUND_WIDTH 240
#define GROUND_HEIGHT 11
#endif