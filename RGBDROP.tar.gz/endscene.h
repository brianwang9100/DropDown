#ifndef ENDSCENE_BITMAP_H
#define ENDSCENE_BITMAP_H
extern const unsigned short endscene[38400];
#define ENDSCENE_WIDTH 240
#define ENDSCENE_HEIGHT 160
#endif